from scapy.all import sniff, IP, TCP, UDP, ICMP
from datetime import datetime

def packet_callback(packet):
    print(f"\n[+] Packet captured at {datetime.now()}")

    if IP in packet:
        ip_layer = packet[IP]
        print(f"IP: {ip_layer.src} -> {ip_layer.dst}")

        if TCP in packet:
            tcp_layer = packet[TCP]
            print(f"TCP: {tcp_layer.sport} -> {tcp_layer.dport}")
        elif UDP in packet:
            udp_layer = packet[UDP]
            print(f"UDP: {udp_layer.sport} -> {udp_layer.dport}")
        elif ICMP in packet:
            print("ICMP Packet Detected")

        print("Payload:", bytes(packet.payload))
    else:
        print("Non-IP Packet")

def start_sniffing(filter_expr="ip"):
    print("Starting packet sniffing...")
    sniff(filter=filter_expr, prn=packet_callback, store=False)

if __name__ == "__main__":
    filter_input = input("Enter BPF filter (e.g., tcp, udp port 53): ")
    start_sniffing(filter_input if filter_input else "ip")
