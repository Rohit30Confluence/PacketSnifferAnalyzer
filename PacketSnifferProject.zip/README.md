# Packet Sniffer and Analyzer

## How to Run (CLI)
```
python packet_sniffer.py
```
Then enter filter like `tcp`, `udp port 53`, or press Enter for default `ip`.

## How to Run (GUI)
```
python gui_sniffer.py
```
A window will open where you can input filters and start sniffing.

## Requirements
- Python 3.x
- Run `pip install scapy`

## Notes
Run with elevated privileges for full access (especially on Linux):
```
sudo python packet_sniffer.py
```