import tkinter as tk
from tkinter import scrolledtext
from scapy.all import sniff, IP, TCP, UDP
import threading

class PacketSnifferApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Packet Sniffer GUI")
        self.create_widgets()
        self.sniffing = False

    def create_widgets(self):
        self.filter_label = tk.Label(self.root, text="Filter (e.g., tcp, udp):")
        self.filter_label.pack()

        self.filter_entry = tk.Entry(self.root, width=50)
        self.filter_entry.pack()

        self.start_button = tk.Button(self.root, text="Start Sniffing", command=self.start_sniffing)
        self.start_button.pack()

        self.stop_button = tk.Button(self.root, text="Stop", command=self.stop_sniffing)
        self.stop_button.pack()

        self.output_text = scrolledtext.ScrolledText(self.root, wrap=tk.WORD, width=80, height=20)
        self.output_text.pack()

    def packet_callback(self, packet):
        if IP in packet:
            ip_src = packet[IP].src
            ip_dst = packet[IP].dst
            proto = "TCP" if TCP in packet else "UDP" if UDP in packet else "Other"
            summary = f"{proto}: {ip_src} -> {ip_dst}\n"
            self.output_text.insert(tk.END, summary)
            self.output_text.see(tk.END)

    def sniff_packets(self):
        sniff(filter=self.filter_entry.get(), prn=self.packet_callback, store=False, stop_filter=lambda x: not self.sniffing)

    def start_sniffing(self):
        self.sniffing = True
        threading.Thread(target=self.sniff_packets, daemon=True).start()

    def stop_sniffing(self):
        self.sniffing = False

if __name__ == "__main__":
    root = tk.Tk()
    app = PacketSnifferApp(root)
    root.mainloop()
